<?php
/* Template Name: Section9 section*/
?>

  <?php get_header();?>

  <div class="container section9">

  </div>

<?php wp_footer(); ?>
