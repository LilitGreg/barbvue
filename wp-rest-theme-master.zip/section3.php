<?php
/* Template Name: Section3 section*/
?>

  <?php get_header();?>

  <div class="container section3">

  </div>

<?php wp_footer(); ?>
