<?php
/* Template Name: Subscirbe section*/
?>

  <div class="subscribe">

    <?php

    if ( is_active_sidebar( 'custom-sidebar' ) ) : ?>
     <ul class="sidebar">
           <?php dynamic_sidebar( 'custom-sidebar' ); ?>
       </ul>
   <?php endif; ?>



  </div>

<?php
 // wp_footer();
  ?>
