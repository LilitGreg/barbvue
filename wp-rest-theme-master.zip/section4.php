<?php
/* Template Name: Section4 section*/
?>

  <?php get_header();?>

  <div class="container section4">

  </div>

<?php wp_footer(); ?>
