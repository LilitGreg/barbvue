<?php
/* Template Name: Footer section*/
?>

  <div class="footer1">

  


  </div>

<?php
 // wp_footer();
  ?>
