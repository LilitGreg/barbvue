<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <?php wp_head(); ?>
</head>
<body>

    <div id="content">

    </div>

    <div id="app"></div>


    <div class="">

     <!-- <div class="section1" id="secton1">
        <div class="container-fluid">
             <img  class="section1-slider"  src="<?php  echo get_theme_mod( 'img-upload', 'No copyright information has been saved yet.' );?>" alt="">

             <div class="arrow">
                        <div class="align-middle">
                            <div id="scrollTitle">SCROLL DOWN</div>
                            <img src="http://le-mugs.com/wp-content/themes/mugs/images/arrow.png">
                        </div>
                    </div>
                    <div class="titleslide" id="titleslide">
                        <div class="logo align-middle">
                            <div class="point1"><img src="http://le-mugs.com/wp-content/themes/mugs/images/point.svg"></div>
                            <div class="point2"><img src="http://le-mugs.com/wp-content/themes/mugs/images/point.svg"></div>
                            <div class="title">

                                <svg version="1.1" id="logo" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                               width="250px"  viewBox="0 0 758 254.5" enable-background="new 0 0 758 254.5" xml:space="preserve">
                               <path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                               M7.833,243.252V8.584l92,118.357l92-118.357v146.333c0,0-2.334,47.334,41.333,73.667s90.556,14.312,112-2.333
                               s37.285-31.001,36.309-82.334l-0.348-17.682"/>
                               <path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                               M573.616,35.451c-20.337-16.784-46.409-26.866-74.837-26.866c-64.977,0-117.651,52.674-117.651,117.651
                               s52.675,117.652,117.651,117.652c50.261,0,93.16-31.516,110.015-75.865H467.167"/>
                               <path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                               M751.542,50.551c0,0-28.042-43.768-97.709-41.909S563.834,46.834,563.5,71.167s12.334,50.333,67,58.667s86.424,8.439,102.333,38.667
                               c13.333,25.333-1.333,64.667-44.333,75.444c-24.646,6.178-70.268,12.248-110.801-27.265"/>
                             </svg>
                            </div>
                            <div class="titleunder">
                                <img src="http://le-mugs.com/wp-content/themes/mugs/images/FDDG-fr.svg">
                            </div>
                        </div>
                    </div>

                    <div class="containerText" id="containerText">
                       <div class="textIntro">
                           <div class="bloc" id="bloc">
                               Découvrez le concept <span>Mugs</span>, Cantine Hype au coeur de <span>Saint-raphaël</span>. Ici tout est fait maison, idéal pour vos <span>brunchs</span> & <span>after works</span>. Let’s go…		</div>
                       </div>
                   </div>



        </div>
     </div> -->


     <!-- <div class="section2 container" id="section2">

       <section class="panel">
           <div class="inside">
               <div class="title">
                   <div class="titleObj">
                       <h2> <?php  echo get_theme_mod( 'section2-title', 'No copyright information has been saved yet.' );?>  </h2>
                   </div>
               </div>
               <div class="imgList">
         <div class="obj"><div class="objimg">  <img  class="section1-slider"  src="<?php  echo get_theme_mod( 'img-section2-gal1', 'No copyright information has been saved yet.' );?>" alt="">
           </div></div>
                   <div class="obj"><div class="objimg"><img  class="section1-slider"  src="<?php  echo get_theme_mod( 'img-section2-gal2', 'No copyright information has been saved yet.' );?>" alt=""></div></div>
                   <div class="obj"><div class="objimg"><img src="<?php  echo get_theme_mod( 'img-section2-gal3', 'No copyright information has been saved yet.' );?> " alt=""></div></div>
                   <div class="obj"><div class="objimg"><img src="<?php  echo get_theme_mod( 'img-section2-gal4', 'No copyright information has been saved yet.' );?> " alt=""> </div></div>
               </div>
               <!-- <div class="p">
                   <div class="pObj">
                       <p><p>Créer un endroit inédit, chaleureux et raffiné, imaginé pour s’y sentir bien, en toute simplicité.</p>
                       </p>
                   </div>
               </div> --
           </div>
       </section>


       <section class="panel">
           <div class="inside">
               <div class="title">
                   <div class="titleObj">
                       <h2>Voyager</h2>
                   </div>
               </div>
               <div class="imgList">
                   <div class="obj"><div class="objimg"><img src="http://le-mugs.com/wp-content/themes/mugs/images/3a.png"></div></div>
                   <div class="obj"><div class="objimg"><img src="http://le-mugs.com/wp-content/themes/mugs/images/3b.png"></div></div>
                   <div class="obj"><div class="objimg"><img src="http://le-mugs.com/wp-content/themes/mugs/images/3c.png"></div></div>
                   <div class="obj"><div class="objimg"><img src="http://le-mugs.com/wp-content/themes/mugs/images/3d.png"></div></div>
               </div>
               <div class="p">
                   <div class="pObj">
                       <p><p>Dans une ambiance puisée ici et ailleurs, pour une atmosphère cosmopolite et authentique.</p>
                       </p>
                   </div>
               </div>
           </div>
       </section>


       <section class="panel">
           <div class="inside">
               <div class="title">
                   <div class="titleObj">
                       <h2>HMMMUGS...</h2>
                   </div>
               </div>
               <div class="imgList">
                   <div class="obj"><div class="objimg"><img src="http://le-mugs.com/wp-content/themes/mugs/images/2a.png"></div></div>
                   <div class="obj"><div class="objimg"><img src="http://le-mugs.com/wp-content/themes/mugs/images/2b.png"></div></div>
                   <div class="obj"><div class="objimg"><img src="http://le-mugs.com/wp-content/themes/mugs/images/2c.png"></div></div>
                   <div class="obj"><div class="objimg"><img src="http://le-mugs.com/wp-content/themes/mugs/images/2d.png"></div></div>
               </div>
               <div class="p">
                   <div class="pObj">
                       <p><p>Couleurs, parfums, matières…un univers conçu pour éveiller les sens.</p>
                       </p>
                   </div>
               </div>
           </div>
       </section>

       <div class="bg1"></div>
       <div class="bg2"></div>
       <div class="bg3"></div>
   </div> -->

 </div>

    <?php wp_footer(); ?>

</body>
</html>
