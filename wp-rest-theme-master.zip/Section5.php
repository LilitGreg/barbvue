<?php
/* Template Name: Section5 section*/
?>

  <?php get_header();?>

  <div class="container section5">

  </div>

<?php wp_footer(); ?>
