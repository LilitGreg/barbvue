<?php
/* Template Name: Home section*/
?>

  <?php get_header();?>

  <div class="container section1">

  </div>

<?php wp_footer(); ?>
