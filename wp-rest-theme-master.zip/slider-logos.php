<?php
/* Template Name: Slider logos section*/
?>

  <?php get_header();?>

  <div class="container section2">

  </div>

<?php wp_footer(); ?>
