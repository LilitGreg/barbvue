<?php

add_theme_support( 'title-tag' );

function rest_theme_scripts() {
	// wp_enqueue_style( 'normalize', get_template_directory_uri() . '/assets/normalize.css', false, '3.0.3' );
	wp_enqueue_style( 'style', get_stylesheet_uri(), array( 'normalize' ) );

	// wp_enqueue_style('mug-css', get_template_directory_uri(). '/assets/style.css');

 //  wp_enqueue_script('prefixfree', get_template_directory_uri() . '/rest-theme/src/js/prefixfree.min.js');
 //
	// wp_enqueue_script('prefixfree', get_template_directory_uri() . '/rest-theme/src/js/modernizr.custom.js.js');
 //
	// wp_enqueue_script('jquery', get_template_directory_uri() . '/rest-theme/src/js/jquery.js');
 //
	// wp_enqueue_script('jquery-migrate', get_template_directory_uri() . '/rest-theme/src/js/jquery-migrate.min.js');
 //
 // wp_enqueue_script('responsiveslides', get_template_directory_uri() . '/rest-theme/src/js/responsiveslides.js');
 //
 // wp_enqueue_script('jquery.parallax', get_template_directory_uri() . '/rest-theme/src/js/jquery.parallax.js');
 //
 // wp_enqueue_script('ScrollMagic', get_template_directory_uri() . '/rest-theme/src/js/ScrollMagic.js');
 // wp_enqueue_script('Mousewheel', get_template_directory_uri() . '/rest-theme/src/js/jquery.mousewheel.js');
 //
 // wp_enqueue_script('Mousewheel', get_template_directory_uri() . '/rest-theme/src/js/jquery.mousewheel.js');
 //
 // wp_enqueue_script('Lethargy', get_template_directory_uri() . '/rest-theme/src/js/lethargy.js');
 //
 // wp_enqueue_script('Lethargy', get_template_directory_uri() . '/rest-theme/src/js/lethargy.js');
 // wp_enqueue_script('Pace', get_template_directory_uri() . '/rest-theme/src/js/pace.min.js');
 // wp_enqueue_script('animationgsap', get_template_directory_uri() . '/rest-theme/src/js/scrollmagic/plugins/animation.gsap.js');
 //
 // wp_enqueue_script('addIndicators', get_template_directory_uri() . '/rest-theme/src/js/scrollmagic/plugins/adebug.addIndicators.js');
 //
 // wp_enqueue_script('TweenMax', 'http://cdnjs.cloudflare.com/ajax/libs/gsap/1.17.0/TweenMax.min.js?ver=4.6.7');
 // wp_enqueue_script('CSSPlugin', 'http://cdnjs.cloudflare.com/ajax/libs/gsap/1.17.0/plugins/CSSPlugin.min.js?ver=4.6.7');
 //
 // wp_enqueue_script('ScrollToPlugin', 'http://cdnjs.cloudflare.com/ajax/libs/gsap/1.17.0/plugins/ScrollToPlugin.min.js?ver=4.6.7');


wp_enqueue_script('bootstrap-js-lib', 'http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js');

wp_enqueue_script('jquery-lib', get_template_directory_uri() . '/rest-theme/src/js/jquery-2.1.4.min.js');

// wp_enqueue_script('customjsssss', 'http://localhost/mug/wp-content/themes/wp-rest-theme-master/rest-theme/src/js/custom.js');


// wp_enqueue_script('customjs', get_template_directory_uri() . '/rest-theme/src/js/custom.js');

 // <script type='text/javascript' src='http://cdnjs.cloudflare.com/ajax/libs/gsap/1.17.0/TweenMax.min.js?ver=4.6.7'></script>
 //     <script type='text/javascript' src='http://cdnjs.cloudflare.com/ajax/libs/gsap/1.17.0/plugins/CSSPlugin.min.js?ver=4.6.7'></script>
 //     <script type='text/javascript' src='http://cdnjs.cloudflare.com/ajax/libs/gsap/1.17.0/plugins/ScrollToPlugin.min.js?ver=4.6.7'></script>

	// <script type='text/javascript' src='http://le-mugs.com/wp-content/themes/mugs/js/scrollmagic/plugins/debug.addIndicators.js?ver=4.6.7'></script>

 // <script type='text/javascript' src='http://le-mugs.com/wp-content/themes/mugs/js/scrollmagic/plugins/debug.addIndicators.js?ver=4.6.7'></script>

	   // <script type='text/javascript' src='http://cdnjs.cloudflare.com/ajax/libs/gsap/1.17.0/TweenMax.min.js?ver=4.6.7'></script>
     // <script type='text/javascript' src='http://cdnjs.cloudflare.com/ajax/libs/gsap/1.17.0/plugins/CSSPlugin.min.js?ver=4.6.7'></script>
     // <script type='text/javascript' src='http://cdnjs.cloudflare.com/ajax/libs/gsap/1.17.0/plugins/ScrollToPlugin.min.js?ver=4.6.7'></script>

		 // <script type='text/javascript' src='http://le-mugs.com/wp-content/themes/mugs/js/scrollmagic/plugins/animation.gsap.js?ver=4.6.7'></script>

 // wp_enqueue_script('mainmin', get_template_directory_uri() . '/rest-theme/src/js/main.min.js');
 // wp_enqueue_script('mainmin', get_template_directory_uri() . '/rest-theme/src/js/main.min.js');

		//
		// <script type='text/javascript' src='http://le-mugs.com/wp-content/plugins/google-analyticator/external-tracking.min.js?ver=6.5.0'></script>

	$base_url  = esc_url_raw( home_url() );
	$base_path = rtrim( parse_url( $base_url, PHP_URL_PATH ), '/' );

	wp_enqueue_script( 'rest-theme-vue', get_template_directory_uri() . '/rest-theme/dist/build.js', array(), '1.0.0', true );
	wp_localize_script( 'rest-theme-vue', 'wp', array(
		'root'      => esc_url_raw( rest_url() ),
		'base_url'  => $base_url,
		'base_path' => $base_path ? $base_path . '/' : '/',
		'nonce'     => wp_create_nonce( 'wp_rest' ),
		'site_name' => get_bloginfo( 'name' ),
		'routes'    => rest_theme_routes(),
	) );
}

add_action( 'wp_enqueue_scripts', 'rest_theme_scripts' );




/*-----------------customization -------------*/


function muga_customizer( $wp_customize ) {
    $wp_customize->add_section(
        'section1',
        array(
            'title' => 'Section1',
            'description' => 'This is a section1.',
            'priority' => 15,
        )
    );


  $wp_customize->add_setting( 'img-upload' );

	$wp_customize->add_control(
	    new WP_Customize_Image_Control(
	        $wp_customize,
	        'img-upload',
	        array(
	            'label' => 'Image Upload',
	            'section' => 'section1',
	            'settings' => 'img-upload'
	        )
	    )
	);


	$wp_customize->add_section(
			'section2',
			array(
					'title' => 'Section2',
					'description' => 'This is a section2.',
					'priority' => 15,
			)
	);


	$wp_customize->add_setting(
		 'section2-title',
		 array(
				 'default' => 'TOUT D’ABORD',
		 )
 );
 $wp_customize->add_control(
		 'section2-title',
		 array(
				 'label' => 'Section2 Title',
				 'section' => 'section2',
				 'type' => 'text',
		 )
 );


$wp_customize->add_setting( 'img-section2-gal1' );

$wp_customize->add_control(
		new WP_Customize_Image_Control(
				$wp_customize,
				'img-section2-gal1',
				array(
						'label' => 'Image Upload',
						'section' => 'section2',
						'settings' => 'img-section2-gal1'
				)
		)
);

$wp_customize->add_setting( 'img-section2-gal2' );

$wp_customize->add_control(
		new WP_Customize_Image_Control(
				$wp_customize,
				'img-section2-gal2',
				array(
						'label' => 'Image Upload',
						'section' => 'section2',
						'settings' => 'img-section2-gal2'
				)
		)
);

$wp_customize->add_setting( 'img-section2-gal3' );

$wp_customize->add_control(
		new WP_Customize_Image_Control(
				$wp_customize,
				'img-section2-gal3',
				array(
						'label' => 'Image Upload',
						'section' => 'section2',
						'settings' => 'img-section2-gal3'
				)
		)
);


$wp_customize->add_setting( 'img-section2-gal4' );

$wp_customize->add_control(
		new WP_Customize_Image_Control(
				$wp_customize,
				'img-section2-gal4',
				array(
						'label' => 'Image Upload',
						'section' => 'section2',
						'settings' => 'img-section2-gal4'
				)
		)
);





}



add_action( 'customize_register', 'muga_customizer' );


function rest_theme_routes() {
	$routes = array();

	$query = new WP_Query( array(
		'post_type'      => 'any',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
	) );
	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			$routes[] = array(
				'id'   => get_the_ID(),
				'type' => get_post_type(),
				'slug' => basename( get_permalink() ),
			);
		}
	}
	wp_reset_postdata();

	return $routes;
}


function mytheme_add_woocommerce_support() {
	add_theme_support( 'woocommerce' );
}
add_action( 'after_setup_theme', 'mytheme_add_woocommerce_support' );


add_filter( 'woocommerce_rest_check_permissions', 'never_trust_bob_with_coupons', 10, 4 );

function never_trust_bob_with_coupons( $permission, $context, $object_id, $type ) {
	return ( 'user' === $type && 'bob' === wp_get_current_user()->user_login ) ? false : $permission;
}


// Enable the option show in rest
add_filter( 'acf/rest_api/field_settings/show_in_rest', '__return_true' );

// Enable the option edit in rest
add_filter( 'acf/rest_api/field_settings/edit_in_rest', '__return_true' );


// add_filter('rest_authentication_errors', function($result) {
//     if (!empty($result)) {
//         return $result;
//     }
//     if (!is_user_logged_in()) {
//         return new WP_Error('restx_logged_out', 'Sorry, you must be logged in to make a request.', array('status' => 401));
//     }
//     return $result;
// });

// add_filter('rest_pre_dispatch', function($result){
//     if (is_user_logged_in()) {
//         return $result;
//     } else {
//         return new WP_Error('rest_requires_authentication', __('Authentication is required for this action.'), array('status' => 403));
//     }
// });


add_action( 'woocommerce_payment_complete', 'my_api_call');
function my_api_call( $order_id ){

	// Order Setup Via WooCommerce

	$order = new WC_Order( $order_id );

	// Iterate Through Items

	$items = $order->get_items();
	foreach ( $items as $item ) {

		// Store Product ID

	$product_id = $item['product_id'];
        $product = new WC_Product($item['product_id']);

        // Check for "API" Category and Run

        if ( has_term( 'api', 'product_cat', $product_id ) ) {

	       	$name		= $order->billing_first_name;
        	$surname	= $order->billing_last_name;
        	$email		= $order->billing_email;
	        $projectsku     = $product->get_sku();
        	$apikey 	= "KEY_GOES_HERE";

        	// API Callout to URL

        	$url = '##API URL##';

			$body = array(
				"Project"	=> $projectsku,
				"Name" 		=> $name,
				"Surname"  	=> $surname,
				"Email"		=> $email,
				"KEY"		=> $apikey
			);

			$response = wp_remote_post( $url,
				array(
					'headers'   => array('Content-Type' => 'application/json; charset=utf-8'),
					'method'    => 'POST',
					'timeout' => 75,
					'body'		=> json_encode($body),
				)
			);

			$vars = json_decode($response['body'],true);

                        // API Response Stored as Post Meta

  			update_post_meta( $order_id, 'meta_message_'.$projectsku, $vars['message'] );
  			update_post_meta( $order_id, 'meta_link_'.$projectsku, $vars['link']);
  			update_post_meta( $order_id, 'did-this-run','yes'); // just there as a checker variable for me
        }

    }
}

function theme_slug_widgets_init() {


    register_sidebar( array(
        'name' => __( 'custom-sidebar', 'theme-slug' ),
        'id' => 'custom-sidebar',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
    		'after_widget'  => '</li>',
    		'before_title'  => '<p class="widgettitle">',
    		'after_title'   => '</p>',
    ) );

}


add_action( 'widgets_init', 'theme_slug_widgets_init' );





////*ROute wp------------->

/**
 * This is our callback function that embeds our phrase in a WP_REST_Response
 */
function prefix_get_endpoint_phrase($data = array()) {

	$key  = ! isset( $data['oauth_consumer_key'] ) ? 0 :  $data['oauth_consumer_key'] ;

	// $key = wc_api_hash( sanitize_text_field( $key ) );


		$emailsb   = ! isset( $data['add_email'] ) ? 0 :  $data['add_email'] ;

		$name = 'Adsffdd';

		 global $wpdb;


		//  $subsc   = $wpdb->get_row(
		//
		//  $wpdb->prepare(
		// 	 "
		//  SELECT wp_newsletter.email
		//  FROM wp_newsletter
		// "
		//  )
		//  );


		 // $record_id = $wpdb->insert_id;


   var_dump($emailsb);

		 $wpdb->insert(
			'wp_newsletter',
			array(
				//'$name' => $name,
				'email' => $emailsb,
				// 'token' => '2bae62b4b3',
				 'status' => 'C'
				//  'id' => 3
			),
			array(
				'%s',
				// '%s',
				// '%s',
				  '%s'
				// '%d'
			)
		);

		// $sql = "INSERT INTO `wp_newsletter`
   //        (`name`,`email`)
   // values ($name, $add_email)";
	 //
	 // 	$wpdb->query($sql);

		// $wpdb->prepare(
		//  "INSERT INTO `wp_newsletter`
		//    (`email`)
		//    values ( '$add_email')"
		//  );

	  //return	$record_id = $wpdb->insert_id;

		//  $wpdb->insert('wp_newsletter', array(
	 //   'email' => $add_email
	 // ));


		/////die(	$emailsb );

    // rest_ensure_response() wraps the data we want to return into a WP_REST_Response, and ensures it will be properly returned.
     return rest_ensure_response( 'Hello World, this is the WordPress REST API' );
}

/**
 * This function is where we register our routes for our example endpoint.
 */
function prefix_register_example_routes() {
    // register_rest_route() handles more arguments but we are going to stick to the basics for now.
    register_rest_route( 'subscription/v1', '/emailsub', array(
        // By using this constant we ensure that when the WP_REST_Server changes our readable endpoints will work as intended.
        'methods'  => WP_REST_Server::CREATABLE,
        // Here we register our callback. The callback is fired when this endpoint is matched by the WP_REST_Server class.
        'callback' => 'prefix_get_endpoint_phrase',

				'args'     => array(
					'add_email' => array(
						'validate_callback' => function( $param, $request, $key ) {
							return is_string ( $param );
						}
					),
					'oauth_consumer_key' => array(
						'default' => 'ck_c730f9e077e564101db07be014d8701187098d70'
					)
				),
    ) );
}

add_action( 'rest_api_init', 'prefix_register_example_routes' );
