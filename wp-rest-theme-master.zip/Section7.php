<?php
/* Template Name: Sliders section*/
?>

  <?php get_header();?>

  <div class="container section7">

  </div>

<?php wp_footer(); ?>
