<?php
/* Template Name: Section8 section*/
?>

  <?php get_header();?>

  <div class="container section8">

  </div>

<?php wp_footer(); ?>
