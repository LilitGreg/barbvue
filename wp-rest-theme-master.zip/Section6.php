<?php
/* Template Name: Section6 section*/
?>

  <?php get_header();?>

  <div class="container section6">

  </div>

<?php wp_footer(); ?>
